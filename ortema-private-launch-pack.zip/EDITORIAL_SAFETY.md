# Ortema Continuity editorial safety rules

These are operating rules for reducing avoidable risk. They are not a substitute for legal advice when a story is disputed, commercially sensitive or unusually high-impact.

## Publish evidence, not certainty we do not possess

- Prefer primary vendor notices, official documentation, regulatory filings and court/registry records.
- Separate confirmed facts, third-party reports, customer reports and Ortema inference.
- State what remains unknown.
- Never turn absence of evidence into “safe”, “no action required” or “nothing will change”.
- Never infer future pricing, layoffs, shutdowns or customer harm merely from an acquisition.

## Avoid prescriptive operational advice

Use:

- “Questions to verify”
- “The vendor documents…”
- “The effect may depend on…”
- “Check the current account-specific position…”

Do not use:

- “Cancel now”
- “Move to X”
- “This is safe”
- “This is the best option”
- “You will save…” unless it is clearly labelled arithmetic from user-entered assumptions

## Claims about people and companies

- Do not publish allegations of dishonesty, illegality, motive or misconduct without strong evidence and director review.
- Avoid loaded labels such as scam, extortion, robbery, bullying or predatory in Ortema's own voice.
- Quote sparingly, attribute clearly and link to the original source.
- Offer a visible correction route and record material corrections.
- If a credible dispute arises, qualify or temporarily remove the claim while the evidence is reviewed.

## Data boundary

- Do not request credentials, exports, invoices, contracts, customer lists or confidential internal records for the public Change Desk.
- Do not copy personal information from public complaints into an Ortema database merely because it is public.
- Do not collect optional analytics or email subscriptions until the data purpose, retention, security and privacy wording have been separately approved.

## Automation boundary

AI or scripts may:

- identify candidate changes;
- compare page versions;
- gather source links;
- draft internal notes;
- flag contradictions.

AI or scripts must not:

- publish automatically;
- send public alerts automatically;
- decide that a vendor is safe or dangerous;
- rank replacements without a human-defined, disclosed method;
- invent customer impact or motive.

## Commercial and investment firewall

- Disclose any paid relationship on the relevant page.
- Do not allow commission size to determine editorial ranking.
- Keep customer/partner non-public information out of personal or company trading decisions.
- Do not publish stock recommendations, trading prompts or market-manipulation tactics through Continuity.
- Any later investment activity must use lawful information and be treated as a separate function with appropriate advice and controls.

## Capacity boundary

Ortema publishes selected coverage. It does not promise complete market monitoring, 24/7 response or guaranteed detection. If the company cannot maintain a page accurately, archive or remove it rather than leaving stale certainty online.
