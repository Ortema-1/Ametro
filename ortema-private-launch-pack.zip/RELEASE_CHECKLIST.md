# Release checklist

## Content and evidence

- [ ] Re-open every primary source linked from the Vimeo and Harvest lead pages.
- [ ] Confirm all dates and wording still match the source on launch day.
- [ ] Update “Last verified” and the revision history only when a human has completed the check.
- [ ] Remove any sentence whose support is unclear.
- [ ] Keep Airtable `noindex` unless a separate, evidenced customer-facing change is established.

## Company and contact

- [ ] Director approves the main ORTEMA positioning.
- [ ] Companies House number, jurisdiction and registered office are correct.
- [ ] Contact form opens the intended company mailbox.
- [ ] No personal email address is printed visibly in page copy.
- [ ] No password, API key, token or private data exists anywhere in the repository.

## Technical

- [ ] Homepage works on desktop and phone.
- [ ] Continuity homepage works on desktop and phone.
- [ ] Vimeo table scrolls inside its container on a narrow phone.
- [ ] Harvest calculator returns the expected arithmetic.
- [ ] Harvest checklist updates the local evidence brief.
- [ ] Print/save-PDF controls open the browser print flow.
- [ ] Vimeo calendar downloads and imports.
- [ ] RSS and sitemap load as XML.
- [ ] 404 page works.
- [ ] Social preview images load over HTTPS.

## Privacy and editorial safety

- [ ] No analytics or non-essential trackers have been added.
- [ ] No user input leaves the browser except when the visitor chooses to send an email.
- [ ] No page tells a business to stay, switch, cancel or renew.
- [ ] No page implies an acquisition guarantees later harm.
- [ ] No affiliate or commercial relationship is omitted.
- [ ] Correction route works through the main contact page.

## Discovery

- [ ] Google Search Console property is verified.
- [ ] `https://ortema.co.uk/sitemap.xml` is submitted.
- [ ] Indexing is requested for the Continuity home, Vimeo brief and Harvest dossier.
- [ ] One transparent public launch post is ready.
- [ ] Community rules are checked before sharing any link.

## Rollback

- [ ] Previous live commit is known.
- [ ] Release is made as one reversible commit.
- [ ] A revert has been tested or the person deploying knows exactly how to perform it.
