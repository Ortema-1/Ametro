# ORTEMA website + Continuity — live-ready release candidate

This package contains the complete static site intended for `https://ortema.co.uk/`.
It has no build step, database, server-side application, analytics service or third-party form backend.

## What is public in this release

- The main ORTEMA technology-company website.
- Ortema Continuity — Software Change Desk.
- A full Vimeo On Demand shutdown brief and downloadable official-date calendar.
- A Harvest ownership/pricing/export dossier with browser-only arithmetic and checklist tools.
- Short briefs for Convictional and Thinkific.
- Methodology, corrections and data-use pages.
- RSS feed and ordinary XML sitemap.

The Airtable acquisition-watch page remains `noindex` and is intentionally excluded from the sitemap because no separate customer-facing impact has been established.

## Contact behaviour

The main contact form does not submit information to a server. It opens a draft in the visitor's own email application.
The recipient address is not printed in visible page copy and is assembled in local JavaScript to deter basic address scrapers. This is not secrecy: any address used by a browser can still be found by a determined person or bot.

A role address such as `contact@ortema.co.uk`, forwarding internally, would be a cleaner long-term public contact than a named mailbox.

## Safety boundaries retained

- No analytics, advertising pixels or behavioural tracking.
- No accounts, mailing list or customer database.
- No customer-file uploads, vendor logins, contracts, invoices or API keys.
- No affiliate links, paid rankings or vendor partnerships.
- No automatic stay/switch/cancel/renew recommendation.
- No automated publication or automated customer alerts.
- No public investment recommendation or market prediction.
- Public claims are linked to identified sources and carry visible verification dates.

## Deployment

1. Keep a copy of the current live repository state or note the current commit.
2. Upload the contents of this ZIP to the repository root in one feature branch or one clearly named commit.
3. Preview the deployment before merging if your hosting setup supports it.
4. Merge/deploy as one change.
5. Verify these live URLs:
   - `/`
   - `/continuity/`
   - `/continuity/incidents/vimeo-vod-shutdown-2026/`
   - `/continuity/incidents/harvest-2026/`
   - `/continuity/methodology/`
   - `/continuity/privacy/`
   - `/continuity/feed.xml`
   - `/sitemap.xml`
6. Test the contact form from a device with an email application configured.
7. Submit the sitemap in Google Search Console and request indexing for the Continuity home, Vimeo and Harvest pages.

## Before pressing publish

- The director should approve the company wording and editorial boundaries.
- Re-open Vimeo's official shutdown notice and seller/viewer FAQs on launch day. If a material date or statement has changed, update the brief and revision history before publishing.
- Confirm the Companies House details in the footer are still correct.
- Check desktop and mobile once through the real hosted URL, not only the local files.
- Do not describe this release as legal, financial, procurement or operational advice.

This is a technical and editorial release candidate, not a legal certification.

## Rollback

The safest deployment is one commit. If anything is wrong, revert that commit.

Continuity is also isolated under `/continuity/`. Removing that folder and the single Continuity links in the main navigation/work section removes the experiment while leaving the rest of the ORTEMA site intact.
