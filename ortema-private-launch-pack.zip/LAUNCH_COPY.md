# First public launch copy

Use only after the live URL has been tested. Keep the disclosure and do not post the same text repeatedly across communities.

## LinkedIn / company post

Vimeo On Demand's first published shutdown milestone begins on 22 August 2026.

Vimeo has set out four dates covering new uploads, purchases and subscriptions, final eligible seller payouts, and the full shutdown of storefronts and viewer access.

I have assembled the official notices into one source-led Ortema Continuity brief, separating:

- what Vimeo confirms for sellers;
- what it says for viewers;
- which data can be exported;
- what does not transfer automatically; and
- what remains account-specific or unknown.

It includes a downloadable calendar and timeline graphic. There are no affiliate links and no replacement service is ranked.

[LIVE VIMEO INCIDENT URL]

I built this at Ortema. Corrections with supporting evidence are welcome through the site.

## Short X / Bluesky version

Vimeo On Demand's published timeline:

22 Aug — new uploads disabled
21 Sep — new purchases/subscriptions disabled
21 Oct — final eligible seller payouts expected
20 Nov — full shutdown and viewer access ends

Official sources, seller/viewer split, calendar + timeline:
[LIVE VIMEO INCIDENT URL]

Built at Ortema. No affiliate links or replacement ranking.

## Community contribution

**Title:** Vimeo On Demand shutdown: official dates, seller exports and viewer access in one place

Vimeo has now published four shutdown milestones, beginning with new uploads being disabled on 22 August and ending with the full shutdown on 20 November 2026.

I went through Vimeo's shutdown notice plus the seller and viewer FAQs and put the confirmed points into one brief. The main distinctions I found were:

- underlying Vimeo videos are not deleted merely because VOD closes;
- sellers can export sales data, but the audience-email export contains only viewers who opted in;
- viewer purchases and watch history do not transfer to another platform;
- downloads depend on the creator's settings;
- Vimeo OTT is presented as a route, but it is not a complete transfer of purchase entitlements.

The page includes a downloadable calendar and a shareable timeline. I built it at Ortema; there are no affiliate links and it does not rank replacement services.

[LIVE VIMEO INCIDENT URL]

Please remove this if links of this kind are not permitted here. Corrections backed by an official source are welcome.

## Rules

- Check the community's rules first.
- Do not claim to be a Vimeo seller or viewer unless that is true.
- Do not imply Ortema is affiliated with Vimeo.
- Do not post from fake accounts or ask others to coordinate votes.
- Answer useful questions in the post itself; do not force every reader through a link.
- Stop after one post or one directly relevant reply per community unless people genuinely continue the discussion.
