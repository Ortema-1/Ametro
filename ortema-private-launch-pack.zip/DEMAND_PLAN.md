# Ortema Continuity — first demand plan

## The hypothesis being tested

People affected by a sudden software change will use and share a calm, source-led incident page when it saves them the work of reconciling scattered official notices, dates, exports and unknowns.

This release does not prove that hypothesis. It creates a credible test.

## Why the Vimeo page has a chance

The opportunity is timely and specific:

- there are four published deadlines;
- sellers and viewers are affected differently;
- the difference between videos, sales data, opted-in audience emails and purchase entitlements is easy to misunderstand;
- affected creators are already looking for replacement routes;
- commercial replacement vendors are already publishing their own migration pages.

The competition means generic “Vimeo alternatives” content is unlikely to win. Ortema's opening position is neutrality, primary-source clarity, a downloadable calendar, a shareable timeline and a dated correction record.

## What makes this more than a ChatGPT answer

- A permanent URL rather than a transient conversation.
- The exact primary sources beside the claims.
- A visible last-verified date and revision history.
- Seller/viewer scope separated explicitly.
- An official-date calendar file.
- A downloadable timeline graphic.
- A brief that can be copied or printed internally.
- A methodology and correction route.

This advantage disappears if the page becomes stale. Currentness and editorial discipline are the product.

## First 72 hours after deployment

### 1. Make discovery technically possible

- Verify the site in Google Search Console.
- Submit `/sitemap.xml`.
- Request indexing for `/continuity/`, the Vimeo brief and the Harvest dossier.
- Confirm the social preview image appears correctly when the Vimeo URL is shared.

Do not expect same-day Google traffic. Search indexing is a medium-term channel, not the launch switch.

### 2. Publish one clear launch item

Post from a real Leon/Ortema identity. State the relationship openly.

The post should lead with the useful facts, not the company:

- Vimeo On Demand has four published milestones.
- The first begins on 22 August 2026.
- The page separates seller data, viewer access and what remains account-specific.
- It includes a calendar and shareable timeline.
- No affiliate relationship or replacement ranking.

Use the timeline graphic. Link directly to the Vimeo incident page, not the ORTEMA homepage.

### 3. Enter existing conversations transparently

Find current creator, filmmaker and Vimeo discussions where the exact factual question is being asked.

- Read each community's self-promotion rules first.
- Answer the question in the post itself.
- Link only when the Ortema page genuinely adds evidence or a useful file.
- Disclose: “I built this at Ortema.”
- Do not use fake accounts, fake testimonials, coordinated votes or planted questions.
- Do not repeatedly paste the same link.

One highly relevant contribution is better than twenty promotional comments.

### 4. Make the asset easy to pass on

Use three forms of the same evidence:

- direct incident URL;
- downloadable calendar;
- timeline graphic.

The goal is not merely a click. It is to make a creator able to send a clean answer to a colleague or audience.

## Week one

- Check Search Console for impressions and exact queries.
- Record public shares, useful replies, correction submissions and genuine inbound questions.
- Update the Vimeo page only when there is new evidence or a correction.
- Publish no thin follow-up article merely to create volume.
- Create one additional page only if actual queries reveal a repeated unresolved question, such as viewer downloads or seller export boundaries.

## Week two decision gate

Continue investing in the Vimeo incident if at least one of these occurs:

- the page begins receiving relevant search impressions;
- people outside Ortema share or cite it;
- a creator says the calendar/timeline/brief was useful;
- a genuine account-specific question reveals a reusable missing tool;
- the page produces a correction or source contribution that improves the dossier.

Change the distribution approach if people click but do not use or share any asset.

Pause the Vimeo-specific work if, after indexing time and several genuinely relevant public placements, there is almost no external engagement. Keep the template and move Radar to the next incident.

## What not to measure yet

Do not judge the concept by vanity page views, broad social impressions or the number of articles published.

The useful early signals are:

- relevant queries;
- external sharing;
- repeat visits after an update;
- calendar/timeline use;
- credible corrections;
- evidence that someone would use Ortema for a second incident.

## Feasible scale while school and director time are constrained

Initial editorial ceiling:

- one full incident dossier at a time;
- up to two short verified briefs in a normal week;
- no promise of real-time or comprehensive coverage;
- no automated public alerts;
- archive anything that cannot be maintained.

Radar can automate candidate detection later. Human verification remains the release gate.

## Scale path only after pull appears

1. Repeat the same template on a second incident.
2. Prove some readers return across incidents.
3. Add a genuine opt-in watch service only after its privacy/security process is ready.
4. Explore disclosed vendor partnerships only after editorial trust exists.
5. Add local conversion or verification tools only where repeated demand identifies a concrete job.
6. Keep any investment-research use legally and operationally separate from customer/partner information.

## Examples worth learning from — not copying blindly

- Have I Been Pwned began as a useful pet project around one clear lookup and expanded after unexpected demand.
- Nomad List began with a simple crowdsourced spreadsheet, then became a site after people used and shared the data.
- Downdetector began with a narrow proof of concept around one repeated newsroom problem, then expanded geographically.
- Techmeme began as a small automated aggregation experiment and later added human editorial judgment.

The common pattern is not “launch an unfinished site and hope”. It is “make one useful object, place it where the relevant people already are, and expand only after behaviour justifies it”. Survivorship bias remains enormous; none of these examples guarantees demand for Ortema.
